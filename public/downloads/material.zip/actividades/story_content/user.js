function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6C8TtLtvh9U":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

